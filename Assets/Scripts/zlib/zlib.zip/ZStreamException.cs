using System;
public class ZStreamException:System.IO.IOException
{
	public ZStreamException():base()
	{
	}
	public ZStreamException(System.String s):base(s)
	{
	}
}
